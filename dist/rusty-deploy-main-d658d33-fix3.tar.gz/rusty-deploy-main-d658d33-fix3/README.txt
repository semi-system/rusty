Rusty Mail Server - deployment kit main-d658d33-fix3

  1. cp swarm.env.example swarm.env     and fill in the nodes and the database (the file is yours: keep it out of version control)
  2. ./rusty-swarm init                 Docker is installed where it is missing, the swarm is made, the database is prepared

Check this file against SHA256SUMS of the release before you unpack it (the sums are signed: docs/docker.md).
